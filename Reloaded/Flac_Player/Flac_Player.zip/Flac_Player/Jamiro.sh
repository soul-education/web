#!/bin/bash
BASE_PATH=$1
SCRIPT_PATH="$(realpath "$0")"
SCRIPT_DIR="$(dirname "$SCRIPT_PATH")"

main() {
  declare -A discos playlists grupos_albums grupos_singles grupos_bootlegs
  opciones=()
  tmpdir=$(mktemp -d)

  # Imagen transparente para encabezados y como icono de ventana
  transparent_img="$tmpdir/transparent.png"
  convert -size 1x1 xc:none "$transparent_img"
  #convert "$SCRIPT_DIR/logo_tarde.png" -resize 512x512 "$SCRIPT_DIR/logo_tarde512.png"

  # Álbumes normales
  while IFS= read -r -d '' dir; do
    nombre=$(basename "$dir")
    [[ "$nombre" == "98. Singles" || "$nombre" == "99. Bootlegs" ]] && continue
    [[ -f "$dir/caratula.jpg" ]] || continue
    playlist=$(find "$dir" -maxdepth 1 -name "*.m3u" | head -n1)
    [[ -n "$playlist" ]] || continue
    discos["$dir"]="$nombre"; playlists["$dir"]="$playlist"
    convert "$dir/caratula.jpg" -resize 200x200\! "$tmpdir/$nombre.jpg"
  done < <(find "$BASE_PATH" -mindepth 2 -maxdepth 2 -type d -print0)

  # Singles/bootlegs
  while IFS= read -r -d '' dir; do
    padre=$(basename "$(dirname "$dir")")
    [[ "$padre" != "98. Singles" && "$padre" != "99. Bootlegs" ]] && continue
    nombre=$(basename "$dir")
    [[ -f "$dir/caratula.jpg" ]] || continue
    playlist=$(find "$dir" -maxdepth 1 -name "*.m3u" | head -n1)
    [[ -n "$playlist" ]] || continue
    discos["$dir"]="$nombre"; playlists["$dir"]="$playlist"
    convert "$dir/caratula.jpg" -resize 200x200\! "$tmpdir/$nombre.jpg"
  done < <(find "$BASE_PATH" -mindepth 3 -maxdepth 3 -type d -print0)

  mapfile -t ordenados < <(for k in "${!discos[@]}"; do echo "$k"; done | sort -V)

  for clave in "${ordenados[@]}"; do
    nombre="${discos[$clave]}"
    padre=$(basename "$(dirname "$clave")")
    abuelo=$(basename "$(dirname "$(dirname "$clave")")")

    if [[ "$padre" == "98. Singles" ]]; then
      artista="$abuelo"; grupos_singles["$artista"]+="$tmpdir/$nombre.jpg|$nombre|$clave"$'\n'
    elif [[ "$padre" == "99. Bootlegs" ]]; then
      artista="$abuelo"; grupos_bootlegs["$artista"]+="$tmpdir/$nombre.jpg|$nombre|$clave"$'\n'
    else
      artista="$(basename "$(dirname "$clave")")"
      grupos_albums["$artista"]+="$tmpdir/$nombre.jpg|$nombre|$clave"$'\n'
    fi
  done

  mapfile -t artistas < <(printf "%s\n" "${!grupos_albums[@]}" "${!grupos_singles[@]}" "${!grupos_bootlegs[@]}" | sort -u -V)

  for artista in "${artistas[@]}"; do
    # Encabezado artista en rojo y +2pt
    opciones+=("$transparent_img" "<span foreground='#a8d8f8' size='12pt'><b>$artista</b></span>" "")

    if [[ -n "${grupos_albums[$artista]}" ]]; then
      while IFS=$'\n' read -r linea; do
        [[ -z "$linea" ]] && continue
        IFS='|' read -r img titulo clave <<< "$linea"
        # Disco con carátula y +2pt
        opciones+=("$img" "<span size='12pt'>   $titulo</span>" "$clave")
      done <<< "${grupos_albums[$artista]}"
    fi

    if [[ -n "${grupos_singles[$artista]}" ]]; then
      # Encabezado singles en naranja y +2pt
      opciones+=("$transparent_img" "   <span foreground='#a8d8f8' size='10pt'><b>$artista Singles</b></span>" "")
      while IFS=$'\n' read -r linea; do
        [[ -z "$linea" ]] && continue
        IFS='|' read -r img titulo clave <<< "$linea"
        opciones+=("$img" "<span size='12pt'>      $titulo</span>" "$clave")
      done <<< "${grupos_singles[$artista]}"
    fi

    if [[ -n "${grupos_bootlegs[$artista]}" ]]; then
      # Encabezado bootlegs en azul y +2pt
      opciones+=("$transparent_img" "   <span foreground='#a8d8f8' size='10pt'><b>$artista Bootlegs</b></span>" "")
      while IFS=$'\n' read -r linea; do
        [[ -z "$linea" ]] && continue
        IFS='|' read -r img titulo clave <<< "$linea"
        opciones+=("$img" "<span size='12pt'>      $titulo</span>" "$clave")
      done <<< "${grupos_bootlegs[$artista]}"
    fi
  done
  seleccion=$(yad --list --no-headers --title="Discrografia de Jamiroquai Flac" --geometry=560x800 \
    --no-click \
    --window-icon="$SCRIPT_DIR/logo128.png" \
    --column="":IMG --column="" --column="Clave":HD "${opciones[@]}")

  [[ -z "$seleccion" ]] && rm -rf "$tmpdir" && exit 0
  clave=$(echo "$seleccion" | cut -d'|' -f3)
  playlist="${playlists[$clave]}"

# Mostrar el GIF en una ventana flotante
if ! pgrep -x gifview > /dev/null; then
	gifview --animate --title "Good vibe zone!" --geometry 512x512 "$SCRIPT_DIR/buffalo_dance.gif" &
	gif_pid=$!
fi



#  vlc "$playlist" &
PLAYLIST_DIR="$(dirname "$playlist")"
OUTFILE="$PLAYLIST_DIR/disco_audacious.m3u"
TMPFILE=$(mktemp)

grep -v '^#EXTVLCOPT' "$playlist" \
  | while read -r line; do
      if [[ "$line" =~ ^# ]]; then
        echo "$line"
      elif [[ -n "$line" ]]; then
        clean=$(echo "$line" | sed -E 's/^ +//; s/%20/ /g; s/%E2%80%99/’/g')
        realpath "$PLAYLIST_DIR/$clean" 2>/dev/null || echo "$clean"
      fi
    done > "$TMPFILE"

mv "$TMPFILE" "$OUTFILE"
audacious "$OUTFILE" &
  wait $!
  rm -rf "$tmpdir"

  exec "$SCRIPT_PATH" "$BASE_PATH" 
}

main
